import hashlib,hmac,json,time
from urllib.parse import parse_qsl
from fastapi import Header,HTTPException
from app.config import BOT_TOKEN

async def auth_user(x_telegram_init_data:str=Header(default="")):
    if not BOT_TOKEN or not x_telegram_init_data:
        raise HTTPException(401,"Откройте Mini App через Telegram")
    try:
        data=dict(parse_qsl(x_telegram_init_data,keep_blank_values=True))
        received=data.pop("hash")
        auth_date=int(data["auth_date"])
        if time.time()-auth_date>86400 or auth_date>time.time()+60:
            raise ValueError("expired")
        check="\n".join(f"{k}={v}" for k,v in sorted(data.items()))
        secret=hmac.new(b"WebAppData",BOT_TOKEN.encode(),hashlib.sha256).digest()
        actual=hmac.new(secret,check.encode(),hashlib.sha256).hexdigest()
        if not hmac.compare_digest(actual,received):
            raise ValueError("signature")
        u=json.loads(data["user"])
        return {"id":int(u["id"]),"first_name":u.get("first_name",""),"username":u.get("username","")}
    except Exception as e:
        raise HTTPException(401,"Не удалось подтвердить авторизацию Telegram") from e
