import os
from dotenv import load_dotenv
load_dotenv()
BOT_TOKEN=os.getenv("BOT_TOKEN","")
WEBAPP_URL=os.getenv("WEBAPP_URL","")
DATABASE_PATH=os.getenv("DATABASE_PATH","./data/worktime.sqlite3")
TIME_ZONE=os.getenv("TIME_ZONE","Europe/Minsk")
HOURLY_RATE=os.getenv("HOURLY_RATE","5.15")
