from pathlib import Path
import aiosqlite
from app.config import DATABASE_PATH

SCHEMA = """
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, first_name TEXT, username TEXT);
CREATE TABLE IF NOT EXISTS shifts(
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
 started_at TEXT NOT NULL, ended_at TEXT, created_at TEXT NOT NULL,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS breaks(
 id INTEGER PRIMARY KEY AUTOINCREMENT, shift_id INTEGER NOT NULL,
 started_at TEXT NOT NULL, ended_at TEXT,
 FOREIGN KEY(shift_id) REFERENCES shifts(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS shifts_user_start ON shifts(user_id,started_at);
CREATE INDEX IF NOT EXISTS breaks_shift ON breaks(shift_id);
"""
async def db_open():
    Path(DATABASE_PATH).parent.mkdir(parents=True,exist_ok=True)
    db=await aiosqlite.connect(DATABASE_PATH)
    db.row_factory=aiosqlite.Row
    await db.execute("PRAGMA foreign_keys=ON")
    await db.execute("PRAGMA busy_timeout=5000")
    return db
async def init_db():
    db=await db_open()
    try:
        await db.executescript(SCHEMA)
        await db.commit()
    finally:
        await db.close()
