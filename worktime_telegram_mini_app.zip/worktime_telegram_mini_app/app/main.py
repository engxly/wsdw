import asyncio
from datetime import datetime,timezone
from decimal import Decimal,ROUND_HALF_UP
from zoneinfo import ZoneInfo
from fastapi import FastAPI,Depends,HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel
from aiogram import Bot,Dispatcher
from aiogram.filters import CommandStart
from aiogram.types import Message,ReplyKeyboardMarkup,KeyboardButton,WebAppInfo,MenuButtonWebApp
from app.config import BOT_TOKEN,WEBAPP_URL,TIME_ZONE,HOURLY_RATE
from app.db import db_open,init_db
from app.auth import auth_user

app=FastAPI(title="WorkTime")
app.mount("/static",StaticFiles(directory="app/static"),name="static")
bot=None
dp=Dispatcher()

def now(): return datetime.now(timezone.utc)
def stamp(d=None): return (d or now()).astimezone(timezone.utc).isoformat(timespec="seconds")
def dt(s): 
    d=datetime.fromisoformat(s.replace("Z","+00:00"))
    return d.replace(tzinfo=timezone.utc) if d.tzinfo is None else d.astimezone(timezone.utc)
def mins(a,b):
    if not a or not b:return 0
    return max(0,int((dt(b)-dt(a)).total_seconds()//60))
def cash(m):
    return str((Decimal(m)*Decimal(HOURLY_RATE)/60).quantize(Decimal("0.01"),rounding=ROUND_HALF_UP))
async def owned(db,sid,uid):
    cur=await db.execute("SELECT * FROM shifts WHERE id=? AND user_id=?",(sid,uid))
    r=await cur.fetchone()
    if not r: raise HTTPException(404,"Смена не найдена")
    return dict(r)
async def payload(db,s):
    cur=await db.execute("SELECT * FROM breaks WHERE shift_id=? ORDER BY started_at",(s["id"],))
    bs=[dict(x) for x in await cur.fetchall()]
    end=s["ended_at"] or stamp()
    gross=mins(s["started_at"],end)
    bm=sum(mins(b["started_at"],b["ended_at"] or stamp()) for b in bs)
    return {**s,"breaks":bs,"gross_minutes":gross,"break_minutes":bm,"paid_minutes":max(0,gross-bm),"earnings":cash(max(0,gross-bm)),"status":"finished" if s["ended_at"] else ("on_break" if any(not b["ended_at"] for b in bs) else "working")}

@dp.message(CommandStart())
async def start(m:Message):
    if not WEBAPP_URL:
        await m.answer("Администратору нужно настроить WEBAPP_URL.")
        return
    kb=ReplyKeyboardMarkup(keyboard=[[KeyboardButton(text="Открыть WorkTime",web_app=WebAppInfo(url=WEBAPP_URL))]],resize_keyboard=True)
    await m.answer("WorkTime — учёт смен и заработка. Нажмите кнопку, чтобы открыть приложение.",reply_markup=kb)

@app.on_event("startup")
async def startup():
    global bot
    await init_db()
    if BOT_TOKEN:
        bot=Bot(BOT_TOKEN)
        if WEBAPP_URL:
            await bot.set_chat_menu_button(menu_button=MenuButtonWebApp(text="WorkTime",web_app=WebAppInfo(url=WEBAPP_URL)))
        asyncio.create_task(dp.start_polling(bot))
@app.on_event("shutdown")
async def shutdown():
    if bot: await bot.session.close()

@app.get("/")
async def index(): return FileResponse("app/static/index.html")
@app.get("/api/me")
async def me(u=Depends(auth_user)):
    return {"user":u,"rate":HOURLY_RATE,"timezone":TIME_ZONE,"currency":"BYN"}

@app.get("/api/dashboard")
async def dashboard(u=Depends(auth_user)):
    db=await db_open()
    try:
        cur=await db.execute("SELECT * FROM shifts WHERE user_id=? AND ended_at IS NULL ORDER BY started_at DESC LIMIT 1",(u["id"],))
        r=await cur.fetchone(); active=await payload(db,dict(r)) if r else None
        tz=ZoneInfo(TIME_ZONE); local=now().astimezone(tz); month=local.replace(day=1,hour=0,minute=0,second=0,microsecond=0).astimezone(timezone.utc)
        cur=await db.execute("SELECT * FROM shifts WHERE user_id=? AND started_at>=?",(u["id"],stamp(month)))
        rows=[dict(x) for x in await cur.fetchall()]
        total=br=0
        for s in rows:
            p=await payload(db,s); total+=p["paid_minutes"]; br+=p["break_minutes"]
        return {"active_shift":active,"paid_minutes":total,"break_minutes":br,"shift_count":len(rows),"earnings":cash(total),"month":local.strftime("%Y-%m")}
    finally: await db.close()

@app.post("/api/shifts/start")
async def start_shift(u=Depends(auth_user)):
    db=await db_open()
    try:
        await db.execute("BEGIN IMMEDIATE")
        await db.execute("INSERT INTO users(id,first_name,username) VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET first_name=excluded.first_name,username=excluded.username",(u["id"],u["first_name"],u["username"]))
        cur=await db.execute("SELECT id FROM shifts WHERE user_id=? AND ended_at IS NULL",(u["id"],))
        if await cur.fetchone(): raise HTTPException(409,"Смена уже открыта")
        t=stamp(); cur=await db.execute("INSERT INTO shifts(user_id,started_at,created_at) VALUES(?,?,?)",(u["id"],t,t))
        await db.commit(); return {"ok":True,"id":cur.lastrowid}
    except: await db.rollback(); raise
    finally: await db.close()

@app.post("/api/shifts/{sid}/break/start")
async def break_start(sid:int,u=Depends(auth_user)):
    db=await db_open()
    try:
        await db.execute("BEGIN IMMEDIATE"); s=await owned(db,sid,u["id"])
        if s["ended_at"]: raise HTTPException(409,"Смена завершена")
        cur=await db.execute("SELECT id FROM breaks WHERE shift_id=? AND ended_at IS NULL",(sid,))
        if await cur.fetchone(): raise HTTPException(409,"Перерыв уже идёт")
        await db.execute("INSERT INTO breaks(shift_id,started_at) VALUES(?,?)",(sid,stamp()))
        await db.commit(); return {"ok":True}
    except: await db.rollback(); raise
    finally: await db.close()

@app.post("/api/shifts/{sid}/break/end")
async def break_end(sid:int,u=Depends(auth_user)):
    db=await db_open()
    try:
        await db.execute("BEGIN IMMEDIATE"); s=await owned(db,sid,u["id"])
        if s["ended_at"]: raise HTTPException(409,"Смена завершена")
        cur=await db.execute("SELECT id FROM breaks WHERE shift_id=? AND ended_at IS NULL",(sid,)); b=await cur.fetchone()
        if not b: raise HTTPException(409,"Нет активного перерыва")
        await db.execute("UPDATE breaks SET ended_at=? WHERE id=?",(stamp(),b["id"]))
        await db.commit(); return {"ok":True}
    except: await db.rollback(); raise
    finally: await db.close()

@app.post("/api/shifts/{sid}/finish")
async def finish(sid:int,u=Depends(auth_user)):
    db=await db_open()
    try:
        await db.execute("BEGIN IMMEDIATE"); s=await owned(db,sid,u["id"])
        if s["ended_at"]: raise HTTPException(409,"Смена уже завершена")
        t=stamp()
        await db.execute("UPDATE breaks SET ended_at=? WHERE shift_id=? AND ended_at IS NULL",(t,sid))
        await db.execute("UPDATE shifts SET ended_at=? WHERE id=?",(t,sid))
        await db.commit(); return {"ok":True}
    except: await db.rollback(); raise
    finally: await db.close()

@app.get("/api/shifts")
async def list_shifts(u=Depends(auth_user)):
    db=await db_open()
    try:
        cur=await db.execute("SELECT * FROM shifts WHERE user_id=? ORDER BY started_at DESC LIMIT 100",(u["id"],))
        return [await payload(db,dict(s)) for s in await cur.fetchall()]
    finally: await db.close()

@app.get("/api/shifts/{sid}")
async def get_shift(sid:int,u=Depends(auth_user)):
    db=await db_open()
    try: return await payload(db,await owned(db,sid,u["id"]))
    finally: await db.close()

class Edit(BaseModel):
    started_at:str
    ended_at:str|None=None
    breaks:list[dict]=[]

@app.patch("/api/shifts/{sid}")
async def edit(sid:int,b:Edit,u=Depends(auth_user)):
    start=dt(b.started_at); end=dt(b.ended_at) if b.ended_at else None
    if end and end<=start: raise HTTPException(400,"Окончание должно быть позже начала")
    if len(b.breaks)>30: raise HTTPException(400,"Слишком много перерывов")
    parsed=[]
    for x in b.breaks:
        bs=dt(x["started_at"]); be=dt(x["ended_at"]) if x.get("ended_at") else None
        if bs<start or (end and bs>end) or (be and (be<=bs or (end and be>end))) or (end and be is None):
            raise HTTPException(400,"Некорректное время перерыва")
        parsed.append((bs,be))
    parsed.sort(key=lambda x:x[0])
    for i in range(1,len(parsed)):
        if parsed[i-1][1] is None or parsed[i][0]<parsed[i-1][1]: raise HTTPException(400,"Перерывы пересекаются")
    db=await db_open()
    try:
        await db.execute("BEGIN IMMEDIATE"); await owned(db,sid,u["id"])
        await db.execute("UPDATE shifts SET started_at=?,ended_at=? WHERE id=?",(stamp(start),stamp(end) if end else None,sid))
        await db.execute("DELETE FROM breaks WHERE shift_id=?",(sid,))
        for bs,be in parsed: await db.execute("INSERT INTO breaks(shift_id,started_at,ended_at) VALUES(?,?,?)",(sid,stamp(bs),stamp(be) if be else None))
        await db.commit(); return {"ok":True}
    except: await db.rollback(); raise
    finally: await db.close()

@app.delete("/api/shifts/{sid}")
async def delete(sid:int,u=Depends(auth_user)):
    db=await db_open()
    try:
        await db.execute("BEGIN IMMEDIATE"); await owned(db,sid,u["id"])
        await db.execute("DELETE FROM shifts WHERE id=?",(sid,)); await db.commit(); return {"ok":True}
    except: await db.rollback(); raise
    finally: await db.close()

@app.get("/api/health")
async def health(): return {"status":"ok"}
